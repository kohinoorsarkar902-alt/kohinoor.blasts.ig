import { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { CellColor, GameModeId, GridCell, PieceShape, ComboNotification } from './types';
import { soundFx } from './utils/audio';
import {
  canPlacePieceAt,
  canPieceFitAnywhere,
  generateTray,
  isGameOver,
} from './utils/shapes';
import {
  createEmptyGrid,
  create8x8ClusteredAreas,
  create116SquaresMegaboard,
  createRandomAreas,
} from './utils/clusterBoards';
import { ScoreHeader } from './components/ScoreHeader';
import { GameBoard } from './components/GameBoard';
import { PieceTray } from './components/PieceTray';
import { PieceBlock } from './components/PieceBlock';
import { GameOverModal } from './components/GameOverModal';
import { ComboBanner } from './components/ComboBanner';

export default function App() {
  const [mode, setMode] = useState<GameModeId>('clustered_areas');
  const [grid, setGrid] = useState<GridCell[][]>(() => create8x8ClusteredAreas());
  const [tray, setTray] = useState<(PieceShape | null)[]>(() => generateTray(3));
  const [selectedPieceId, setSelectedPieceId] = useState<string | null>(null);

  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('block_blast_high_score');
      return saved ? parseInt(saved, 10) : 0;
    }
    return 0;
  });
  const [combo, setCombo] = useState<number>(1);
  const [blastStreak, setBlastStreak] = useState<number>(0);
  const [remainingTimerSec, setRemainingTimerSec] = useState<number>(0);
  const lastBlastTimeRef = useRef<number | null>(null);

  const [isGameOverState, setIsGameOverState] = useState<boolean>(false);
  const [isNewHigh, setIsNewHigh] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Floating combo banner
  const [comboNotification, setComboNotification] = useState<ComboNotification | null>(null);

  // Dragging state
  const [draggingPiece, setDraggingPiece] = useState<PieceShape | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);
  const [isTouchDrag, setIsTouchDrag] = useState<boolean>(false);
  const [previewPlacement, setPreviewPlacement] = useState<{
    row: number;
    col: number;
    isValid: boolean;
  } | null>(null);

  const boardRef = useRef<HTMLDivElement | null>(null);

  // Active 8-second countdown timer loop
  useEffect(() => {
    const interval = setInterval(() => {
      if (lastBlastTimeRef.current !== null) {
        const elapsed = Date.now() - lastBlastTimeRef.current;
        const remainingMs = 8000 - elapsed;
        if (remainingMs > 0) {
          setRemainingTimerSec(remainingMs / 1000);
        } else {
          // 8 seconds have passed without another blast! Reset streak
          setRemainingTimerSec(0);
          setBlastStreak(0);
          lastBlastTimeRef.current = null;
        }
      } else {
        setRemainingTimerSec(0);
      }
    }, 50);

    return () => clearInterval(interval);
  }, []);

  // Sync soundFx muted state
  const handleToggleMute = useCallback(() => {
    soundFx.enabled = !soundFx.enabled;
    setIsMuted(!soundFx.enabled);
  }, []);

  // Initialize board by mode
  const initBoard = useCallback((selectedMode: GameModeId) => {
    let newGrid: GridCell[][];
    if (selectedMode === 'classic8') {
      newGrid = createEmptyGrid(8, 8);
    } else if (selectedMode === 'mega116') {
      newGrid = create116SquaresMegaboard().grid;
    } else {
      // Clustered areas (preset grouped blocks)
      newGrid = create8x8ClusteredAreas();
    }

    setGrid(newGrid);
    setTray(generateTray(3));
    setSelectedPieceId(null);
    setScore(0);
    setCombo(1);
    setBlastStreak(0);
    setRemainingTimerSec(0);
    lastBlastTimeRef.current = null;
    setIsGameOverState(false);
    setIsNewHigh(false);
    setPreviewPlacement(null);
  }, []);

  // Regenerate random clusters in Clustered Areas mode
  const handleRegenerateClusters = useCallback(() => {
    const newGrid = createRandomAreas(8, 8, 4);
    setGrid(newGrid);
    setTray(generateTray(3));
    setSelectedPieceId(null);
    setScore(0);
    setCombo(1);
    setBlastStreak(0);
    setRemainingTimerSec(0);
    lastBlastTimeRef.current = null;
    setIsGameOverState(false);
    setIsNewHigh(false);
    setPreviewPlacement(null);
  }, []);

  const handleSelectMode = useCallback((newMode: GameModeId) => {
    setMode(newMode);
    initBoard(newMode);
  }, [initBoard]);

  const activePiece = draggingPiece || tray.find((p) => p && p.id === selectedPieceId) || null;

  // Compute which pieces can currently fit anywhere on the board
  const canFitMap = tray.reduce<Record<string, boolean>>((acc, piece) => {
    if (piece) {
      acc[piece.id] = canPieceFitAnywhere(grid, piece);
    }
    return acc;
  }, {});

  // Update high score
  const updateScore = useCallback((added: number) => {
    setScore((prev) => {
      const next = prev + added;
      setHighScore((currentHigh) => {
        if (next > currentHigh) {
          localStorage.setItem('block_blast_high_score', next.toString());
          setIsNewHigh(true);
          return next;
        }
        return currentHigh;
      });
      return next;
    });
  }, []);

  // Check lines to blast
  const checkAndBlastLines = useCallback(
    (currentGrid: GridCell[][], lastMoveCombo: number): { nextGrid: GridCell[][]; linesCleared: number } => {
      const rows = currentGrid.length;
      const cols = currentGrid[0].length;

      const rowsToBlast: number[] = [];
      const colsToBlast: number[] = [];

      // Check filled rows
      for (let r = 0; r < rows; r++) {
        let isRowFull = true;
        for (let c = 0; c < cols; c++) {
          if (!currentGrid[r][c].filled) {
            isRowFull = false;
            break;
          }
        }
        if (isRowFull) rowsToBlast.push(r);
      }

      // Check filled cols
      for (let c = 0; c < cols; c++) {
        let isColFull = true;
        for (let r = 0; r < rows; r++) {
          if (!currentGrid[r][c].filled) {
            isColFull = false;
            break;
          }
        }
        if (isColFull) colsToBlast.push(c);
      }

      const totalLines = rowsToBlast.length + colsToBlast.length;

      if (totalLines === 0) {
        return { nextGrid: currentGrid, linesCleared: 0 };
      }

      // Mark cells for blast animation
      const nextGrid = currentGrid.map((rowArr, rIdx) =>
        rowArr.map((cell, cIdx) => {
          if (rowsToBlast.includes(rIdx) || colsToBlast.includes(cIdx)) {
            return { ...cell, isBlasting: true };
          }
          return { ...cell };
        })
      );

      // --- 8-SECOND TIME-BASED DOUBLE SCORE RULE ---
      // 1st blast: 20 score
      // 2nd blast within 8 seconds: Double score (40 pts)
      // Blast after 8s: 20 score
      const now = Date.now();
      const isWithin8sWindow =
        lastBlastTimeRef.current !== null && (now - lastBlastTimeRef.current) <= 8000;

      let blastScore = 20;
      let nextStreak = 1;

      if (isWithin8sWindow && blastStreak >= 1) {
        // Second or consecutive blast within 8 seconds!
        nextStreak = blastStreak + 1;
        blastScore = 20 * Math.pow(2, nextStreak - 1); // 2nd blast = 40 pts, 3rd = 80 pts...
      } else {
        // First blast, or single blast outside 8 seconds
        nextStreak = 1;
        blastScore = 20;
      }

      setBlastStreak(nextStreak);
      setCombo(nextStreak);
      lastBlastTimeRef.current = now;
      setRemainingTimerSec(8.0);
      updateScore(blastScore);

      // Play audio & trigger celebratory effects
      soundFx.playClear(totalLines, nextStreak);

      if (nextStreak >= 2) {
        // Double blast or higher celebration
        confetti({
          particleCount: Math.min(nextStreak * 35, 90),
          spread: 80,
          origin: { y: 0.6 },
        });

        setComboNotification({
          id: Date.now(),
          text: `×2 +${blastScore} PTS!`,
          count: totalLines,
          multiplier: 2,
        });
      } else {
        // First blast or reset single blast
        setComboNotification({
          id: Date.now(),
          text: '💥 +20 PTS',
          count: totalLines,
          multiplier: 1,
        });
      }

      setTimeout(() => {
        setComboNotification(null);
      }, 1500);

      // Clean up blasted cells after animation
      setTimeout(() => {
        setGrid((g) =>
          g.map((rowArr, rIdx) =>
            rowArr.map((cell, cIdx) => {
              if (rowsToBlast.includes(rIdx) || colsToBlast.includes(cIdx)) {
                return { filled: false };
              }
              return cell;
            })
          )
        );
      }, 200);

      return { nextGrid, linesCleared: totalLines };
    },
    [updateScore, blastStreak]
  );

  // Execute placement of a piece
  const executePlacement = useCallback(
    (piece: PieceShape, targetRow: number, targetCol: number) => {
      if (!canPlacePieceAt(grid, piece, targetRow, targetCol)) {
        return false;
      }

      soundFx.playDrop();

      const updatedGrid = grid.map((rowArr) => rowArr.map((cell) => ({ ...cell })));

      for (let r = 0; r < piece.height; r++) {
        for (let c = 0; c < piece.width; c++) {
          if (piece.matrix[r][c] === 1) {
            const bR = targetRow + r;
            const bC = targetCol + c;
            updatedGrid[bR][bC] = {
              filled: true,
              color: piece.color,
            };
          }
        }
      }

      // Check lines & blast (scores awarded only on blast according to rules)
      const { nextGrid } = checkAndBlastLines(updatedGrid, combo);
      setGrid(nextGrid);

      // Remove placed piece from tray
      let updatedTray = tray.map((p) => (p && p.id === piece.id ? null : p));

      // If all pieces placed, spawn 3 new pieces
      const remainingPieces = updatedTray.filter((p): p is PieceShape => p !== null);
      if (remainingPieces.length === 0) {
        updatedTray = generateTray(3);
      }

      setTray(updatedTray);
      setSelectedPieceId(null);
      setPreviewPlacement(null);

      // Check game over
      const activeRemaining = updatedTray.filter((p): p is PieceShape => p !== null);
      if (isGameOver(nextGrid, activeRemaining)) {
        soundFx.playGameOver();
        setIsGameOverState(true);
      }

      return true;
    },
    [grid, combo, tray, checkAndBlastLines]
  );

  // Click on a cell to place selected piece
  const handleCellClick = useCallback(
    (row: number, col: number) => {
      if (!activePiece) return;
      executePlacement(activePiece, row, col);
    },
    [activePiece, executePlacement]
  );

  // Hover over cell when piece is selected
  const handleCellHover = useCallback(
    (row: number, col: number) => {
      if (!activePiece || draggingPiece) return;
      const isValid = canPlacePieceAt(grid, activePiece, row, col);
      setPreviewPlacement({ row, col, isValid });
    },
    [activePiece, draggingPiece, grid]
  );

  // Drag start
  const handleDragStart = useCallback((piece: PieceShape, clientX: number, clientY: number) => {
    soundFx.playPick();
    setDraggingPiece(piece);
    setSelectedPieceId(piece.id);
    setDragPos({ x: clientX, y: clientY });
  }, []);

  // Convert screen coordinates to board cell
  const getBoardCoords = useCallback(
    (clientX: number, clientY: number, piece: PieceShape, isTouch: boolean) => {
      if (!boardRef.current) return null;

      const rect = boardRef.current.getBoundingClientRect();
      const rows = grid.length;
      const cols = grid[0].length;

      const cellWidth = rect.width / cols;
      const cellHeight = rect.height / rows;

      // When dragging on touch devices, offset the target up so finger doesn't block the piece
      const touchOffsetY = isTouch ? 65 : 0;
      const targetY = clientY - touchOffsetY;

      // Center piece on touch point
      const pieceCenterX = (piece.width * cellWidth) / 2;
      const pieceCenterY = (piece.height * cellHeight) / 2;

      const col = Math.floor((clientX - rect.left - pieceCenterX + cellWidth / 2) / cellWidth);
      const row = Math.floor((targetY - rect.top - pieceCenterY + cellHeight / 2) / cellHeight);

      return { row, col };
    },
    [grid]
  );

  // Global drag move & end listeners
  useEffect(() => {
    if (!draggingPiece) return;

    const handleMouseMove = (e: MouseEvent) => {
      setDragPos({ x: e.clientX, y: e.clientY });
      setIsTouchDrag(false);

      const coords = getBoardCoords(e.clientX, e.clientY, draggingPiece, false);
      if (coords) {
        const isValid = canPlacePieceAt(grid, draggingPiece, coords.row, coords.col);
        setPreviewPlacement({ row: coords.row, col: coords.col, isValid });
      } else {
        setPreviewPlacement(null);
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      const coords = getBoardCoords(e.clientX, e.clientY, draggingPiece, false);
      if (coords) {
        executePlacement(draggingPiece, coords.row, coords.col);
      }
      setDraggingPiece(null);
      setDragPos(null);
      setPreviewPlacement(null);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        setDragPos({ x: touch.clientX, y: touch.clientY });
        setIsTouchDrag(true);

        const coords = getBoardCoords(touch.clientX, touch.clientY, draggingPiece, true);
        if (coords) {
          const isValid = canPlacePieceAt(grid, draggingPiece, coords.row, coords.col);
          setPreviewPlacement({ row: coords.row, col: coords.col, isValid });
        } else {
          setPreviewPlacement(null);
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (e.changedTouches.length > 0) {
        const touch = e.changedTouches[0];
        const coords = getBoardCoords(touch.clientX, touch.clientY, draggingPiece, true);
        if (coords) {
          executePlacement(draggingPiece, coords.row, coords.col);
        }
      }
      setDraggingPiece(null);
      setDragPos(null);
      setPreviewPlacement(null);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
    window.addEventListener('touchend', handleTouchEnd);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [draggingPiece, grid, getBoardCoords, executePlacement]);

  return (
    <div className="min-h-screen text-slate-100 flex flex-col items-center justify-between p-3 sm:p-5 relative overflow-x-hidden font-sans select-none">
      {/* Subtle radial ambient background glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-gradient-to-b from-cyan-500/10 via-purple-500/5 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Floating Combo Burst Banner */}
      <ComboBanner notification={comboNotification} />

      {/* Top Header & Stats */}
      <div className="w-full max-w-lg mb-3 sm:mb-4">
        <ScoreHeader
          score={score}
          highScore={highScore}
          combo={combo}
          blastStreak={blastStreak}
          remainingTimerSec={remainingTimerSec}
          currentMode={mode}
          onSelectMode={handleSelectMode}
          onReset={() => initBoard(mode)}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onRegenerateClusters={handleRegenerateClusters}
        />
      </div>

      {/* Central Interactive Board */}
      <main className="w-full max-w-lg flex flex-col items-center justify-center my-auto">
        <GameBoard
          grid={grid}
          previewPlacement={previewPlacement}
          activePiece={activePiece}
          onCellClick={handleCellClick}
          onCellHover={handleCellHover}
          boardRef={boardRef}
        />

        {/* Tip for desktop and mobile */}
        <div className="mt-2.5 px-3 py-1 rounded-full bg-slate-900/40 border border-slate-800/60 backdrop-blur-sm">
          <p className="text-[11px] text-slate-400 text-center font-medium">
            {activePiece
              ? 'Click on the board or drag to position and blast lines'
              : 'Drag or tap any shape below to place it on the board'}
          </p>
        </div>
      </main>

      {/* Bottom Tray with 3 Pieces */}
      <footer className="w-full max-w-lg mt-3 sm:mt-4">
        <PieceTray
          pieces={tray}
          selectedPieceId={selectedPieceId}
          onSelectPiece={(p) => {
            soundFx.playPick();
            setSelectedPieceId(p ? p.id : null);
            setPreviewPlacement(null);
          }}
          onDragStart={handleDragStart}
          canFitMap={canFitMap}
        />
      </footer>

      {/* Floating Dragging Piece Overlay */}
      {draggingPiece && dragPos && (
        <div
          className="fixed pointer-events-none z-50 transition-transform duration-75 scale-110 drop-shadow-2xl"
          style={{
            left: `${dragPos.x}px`,
            top: `${dragPos.y - (isTouchDrag ? 65 : 0)}px`,
            transform: 'translate(-50%, -50%)',
          }}
        >
          <PieceBlock piece={draggingPiece} size="md" />
        </div>
      )}

      {/* Game Over Dialog */}
      {isGameOverState && (
        <GameOverModal
          score={score}
          highScore={highScore}
          isNewHigh={isNewHigh}
          onRestart={() => initBoard(mode)}
          onSwitchMode={() => {
            setIsGameOverState(false);
            const nextMode: GameModeId =
              mode === 'classic8' ? 'clustered_areas' : mode === 'clustered_areas' ? 'mega116' : 'classic8';
            handleSelectMode(nextMode);
          }}
        />
      )}
    </div>
  );
}
