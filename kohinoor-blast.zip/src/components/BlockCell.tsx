import React from 'react';
import { CellColor, GridCell } from '../types';
import { COLOR_STYLES } from '../utils/shapes';

interface BlockCellProps {
  cell: GridCell;
  row: number;
  col: number;
  previewColor?: CellColor;
  onCellClick?: (row: number, col: number) => void;
  onCellMouseEnter?: (row: number, col: number) => void;
  cellSizeClass?: string;
}

export const BlockCell: React.FC<BlockCellProps> = ({
  cell,
  row,
  col,
  previewColor,
  onCellClick,
  onCellMouseEnter,
  cellSizeClass = 'w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14',
}) => {
  const isFilled = cell.filled;
  const isBlasting = cell.isBlasting;
  const isPreview = cell.isPreview;
  const isValidPreview = cell.isValidPreview;

  let cellContent = null;

  if (isFilled && cell.color) {
    const style = COLOR_STYLES[cell.color] || COLOR_STYLES.sapphire;
    cellContent = (
      <div
        className={`w-full h-full rounded-[7px] sm:rounded-[8px] transition-all duration-150 ${style.gradient} ${style.glow} border-t-2 border-l-2 ${style.borderTop} border-b-2 border-r-2 ${style.borderBottom} relative overflow-hidden flex items-center justify-center ${
          isBlasting
            ? 'scale-110 brightness-200 shadow-[0_0_24px_rgba(255,255,255,0.9)] animate-pulse'
            : 'scale-100 shadow-md'
        }`}
      >
        {/* Specular gloss top reflection */}
        <div className="absolute top-0 inset-x-0 h-2/5 bg-gradient-to-b from-white/35 to-transparent rounded-t-[6px] pointer-events-none" />
        
        {/* Crisp diamond corner glare */}
        <div className="w-1.5 h-1.5 rounded-full bg-white/70 absolute top-1 left-1 blur-[0.5px] pointer-events-none" />
        
        {/* Subtle center jewel facet */}
        <div className="w-2.5 h-2.5 rounded-sm border border-white/20 rotate-45 pointer-events-none opacity-40" />
      </div>
    );
  } else if (isPreview && previewColor) {
    const style = COLOR_STYLES[previewColor] || COLOR_STYLES.sapphire;
    cellContent = (
      <div
        className={`w-full h-full rounded-[7px] sm:rounded-[8px] transition-all border-2 ${
          isValidPreview
            ? `${style.hologram} animate-pulse`
            : 'bg-rose-500/25 border-rose-400/70 shadow-[0_0_8px_rgba(244,63,94,0.4)]'
        }`}
      />
    );
  }

  return (
    <button
      type="button"
      id={`cell-${row}-${col}`}
      onClick={() => onCellClick?.(row, col)}
      onMouseEnter={() => onCellMouseEnter?.(row, col)}
      className={`${cellSizeClass} rounded-xl bg-slate-900/50 hover:bg-slate-850 border border-slate-800/70 hover:border-slate-700/80 shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)] p-0.5 sm:p-1 transition-all flex items-center justify-center relative focus:outline-none`}
      aria-label={`Grid cell ${row + 1}, ${col + 1}${isFilled ? ' occupied' : ' empty'}`}
    >
      {/* Precision recessed micro-dot for empty cells */}
      {!isFilled && !isPreview && (
        <div className="w-1.5 h-1.5 rounded-full bg-slate-700/50 pointer-events-none" />
      )}
      {cellContent}
    </button>
  );
};
