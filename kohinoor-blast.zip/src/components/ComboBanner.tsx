import React from 'react';
import { ComboNotification } from '../types';

interface ComboBannerProps {
  notification: ComboNotification | null;
}

export const ComboBanner: React.FC<ComboBannerProps> = ({ notification }) => {
  if (!notification) return null;

  return (
    <div className="fixed top-20 sm:top-24 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-in zoom-in-95 duration-150">
      <div className="px-6 sm:px-8 py-2.5 sm:py-3 rounded-full bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 text-white font-black text-lg sm:text-2xl shadow-[0_0_40px_rgba(244,63,94,0.7)] border-2 border-white/90 flex items-center gap-2.5 tracking-wider uppercase backdrop-blur-md">
        <span className="text-xl sm:text-2xl drop-shadow">⚡</span>
        <span className="drop-shadow">{notification.text}</span>
        {notification.subtext && (
          <span className="text-yellow-200 text-sm sm:text-base font-extrabold normal-case tracking-normal">
            ({notification.subtext})
          </span>
        )}
      </div>
    </div>
  );
};
