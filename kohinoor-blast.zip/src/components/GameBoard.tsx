import React, { useRef } from 'react';
import { CellColor, GridCell, PieceShape } from '../types';
import { BlockCell } from './BlockCell';

interface GameBoardProps {
  grid: GridCell[][];
  previewPlacement: { row: number; col: number; isValid: boolean } | null;
  activePiece: PieceShape | null;
  onCellClick: (row: number, col: number) => void;
  onCellHover: (row: number, col: number) => void;
  boardRef: React.RefObject<HTMLDivElement | null>;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  grid,
  previewPlacement,
  activePiece,
  onCellClick,
  onCellHover,
  boardRef,
}) => {
  const rows = grid.length;
  const cols = grid[0].length;

  // Build a preview mask
  const previewCells = new Set<string>();
  let previewColor: CellColor | undefined = undefined;
  let isValidPlacement = false;

  if (previewPlacement && activePiece) {
    const { row: pRow, col: pCol, isValid } = previewPlacement;
    isValidPlacement = isValid;
    previewColor = activePiece.color;

    for (let r = 0; r < activePiece.height; r++) {
      for (let c = 0; c < activePiece.width; c++) {
        if (activePiece.matrix[r][c] === 1) {
          const boardR = pRow + r;
          const boardC = pCol + c;
          if (boardR >= 0 && boardR < rows && boardC >= 0 && boardC < cols) {
            previewCells.add(`${boardR}-${boardC}`);
          }
        }
      }
    }
  }

  // Adjust cell size dynamically based on grid dimensions
  const cellSizeClass =
    rows > 8
      ? 'w-7 h-7 sm:w-8 sm:h-8 md:w-9 md:h-9'
      : 'w-9 h-9 sm:w-11 sm:h-11 md:w-13 md:h-13';

  return (
    <div
      ref={boardRef}
      id="game-board"
      className="relative p-2.5 sm:p-4 bg-slate-950/80 rounded-3xl border border-slate-800/80 shadow-[0_20px_60px_rgba(0,0,0,0.7),inset_0_1px_1px_rgba(255,255,255,0.08)] backdrop-blur-xl select-none touch-none ring-1 ring-white/5"
    >
      {/* Corner precision accents */}
      <div className="absolute top-2 left-2 w-2 h-2 border-t border-l border-slate-700/60 rounded-tl-sm pointer-events-none" />
      <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-slate-700/60 rounded-tr-sm pointer-events-none" />
      <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-slate-700/60 rounded-bl-sm pointer-events-none" />
      <div className="absolute bottom-2 right-2 w-2 h-2 border-b border-r border-slate-700/60 rounded-br-sm pointer-events-none" />

      <div
        className="grid gap-1 sm:gap-1.5"
        style={{
          gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
        }}
      >
        {grid.map((rowCells, rIdx) =>
          rowCells.map((cell, cIdx) => {
            const key = `${rIdx}-${cIdx}`;
            const isCellInPreview = previewCells.has(key);

            const displayCell: GridCell = {
              ...cell,
              isPreview: isCellInPreview && !cell.filled,
              isValidPreview: isValidPlacement,
            };

            return (
              <BlockCell
                key={key}
                cell={displayCell}
                row={rIdx}
                col={cIdx}
                cellSizeClass={cellSizeClass}
                previewColor={previewColor}
                onCellClick={onCellClick}
                onCellMouseEnter={onCellHover}
              />
            );
          })
        )}
      </div>
    </div>
  );
};
