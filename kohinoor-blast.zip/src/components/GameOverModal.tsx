import React from 'react';
import { Trophy, RotateCcw, Award } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewHigh: boolean;
  onRestart: () => void;
  onSwitchMode: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  isNewHigh,
  onRestart,
  onSwitchMode,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900/90 border border-slate-700/80 rounded-3xl p-6 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] text-center flex flex-col items-center gap-5 relative overflow-hidden ring-1 ring-white/10">
        {/* Glow backdrop */}
        <div className="absolute -top-24 -left-24 w-52 h-52 bg-rose-500/25 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-52 h-52 bg-amber-500/25 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-1">
          <span className="text-xs uppercase tracking-widest text-rose-400 font-extrabold">
            No more moves!
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white drop-shadow">
            GAME OVER
          </h2>
        </div>

        {isNewHigh && (
          <div className="w-full py-2.5 px-3.5 rounded-2xl bg-gradient-to-r from-amber-500/25 to-yellow-500/25 border border-amber-400/60 text-amber-300 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.2)] animate-pulse">
            <Award className="w-4 h-4 text-amber-400" />
            NEW PERSONAL BEST!
          </div>
        )}

        <div className="w-full grid grid-cols-2 gap-3">
          <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/90 shadow-inner">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block mb-1">Score</span>
            <span className="text-2xl sm:text-3xl font-black text-white font-mono">{score}</span>
          </div>
          <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/90 shadow-inner">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-1 flex items-center justify-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-yellow-400" /> Best
            </span>
            <span className="text-2xl sm:text-3xl font-black text-yellow-400 font-mono">{highScore}</span>
          </div>
        </div>

        <div className="w-full flex flex-col gap-2.5 pt-1">
          <button
            type="button"
            id="modal-play-again-btn"
            onClick={onRestart}
            className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500 hover:brightness-110 text-slate-950 font-black text-sm tracking-wide shadow-xl shadow-rose-500/25 active:scale-98 transition-all flex items-center justify-center gap-2 uppercase"
          >
            <RotateCcw className="w-5 h-5" />
            PLAY AGAIN
          </button>

          <button
            type="button"
            id="modal-change-mode-btn"
            onClick={onSwitchMode}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-300 hover:text-white font-semibold text-xs border border-slate-700/80 transition-colors"
          >
            Switch Game Mode
          </button>
        </div>
      </div>
    </div>
  );
};
