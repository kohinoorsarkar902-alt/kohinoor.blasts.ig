import React from 'react';
import { PieceShape } from '../types';
import { COLOR_STYLES } from '../utils/shapes';

interface PieceBlockProps {
  piece: PieceShape;
  size?: 'sm' | 'md' | 'lg';
  canFit?: boolean;
}

export const PieceBlock: React.FC<PieceBlockProps> = ({
  piece,
  size = 'md',
  canFit = true,
}) => {
  const style = COLOR_STYLES[piece.color] || COLOR_STYLES.amber;

  // Sizing of individual blocks in the piece preview
  const blockSize =
    size === 'sm'
      ? 'w-5 h-5'
      : size === 'md'
      ? 'w-7 h-7 sm:w-8 sm:h-8'
      : 'w-10 h-10 sm:w-12 sm:h-12';

  return (
    <div
      className={`inline-grid gap-1 transition-opacity select-none ${
        !canFit ? 'opacity-35 grayscale-[50%]' : 'opacity-100'
      }`}
      style={{
        gridTemplateColumns: `repeat(${piece.width}, minmax(0, 1fr))`,
      }}
    >
      {piece.matrix.map((row, rIdx) =>
        row.map((val, cIdx) => (
          <div key={`${piece.id}-${rIdx}-${cIdx}`} className={`${blockSize} flex items-center justify-center`}>
            {val === 1 ? (
              <div
                className={`w-full h-full rounded-[6px] ${style.gradient} ${style.glow} border-t-2 border-l-2 ${style.borderTop} border-b-2 border-r-2 ${style.borderBottom} relative overflow-hidden shadow-sm`}
              >
                {/* 3D highlight shine */}
                <div className="absolute top-0 inset-x-0 h-2/5 bg-gradient-to-b from-white/35 to-transparent rounded-t-[4px] pointer-events-none" />
                <div className="w-1 h-1 rounded-full bg-white/70 absolute top-0.5 left-0.5 pointer-events-none" />
              </div>
            ) : (
              <div className="w-full h-full opacity-0 pointer-events-none" />
            )}
          </div>
        ))
      )}
    </div>
  );
};
