import React from 'react';
import { PieceShape } from '../types';
import { PieceBlock } from './PieceBlock';

interface PieceTrayProps {
  pieces: (PieceShape | null)[];
  selectedPieceId: string | null;
  onSelectPiece: (piece: PieceShape | null) => void;
  onDragStart: (piece: PieceShape, clientX: number, clientY: number) => void;
  canFitMap: Record<string, boolean>;
}

export const PieceTray: React.FC<PieceTrayProps> = ({
  pieces,
  selectedPieceId,
  onSelectPiece,
  onDragStart,
  canFitMap,
}) => {
  return (
    <div
      id="piece-tray"
      className="w-full max-w-xl mx-auto px-2.5 py-3.5 bg-slate-950/80 border border-slate-800/80 rounded-3xl backdrop-blur-xl shadow-[0_12px_40px_rgba(0,0,0,0.6),inset_0_1px_1px_rgba(255,255,255,0.06)] flex items-center justify-around gap-2.5 min-h-[120px] sm:min-h-[140px] ring-1 ring-white/5"
    >
      {pieces.map((piece, index) => {
        if (!piece) {
          return (
            <div
              key={`empty-slot-${index}`}
              className="flex-1 flex items-center justify-center h-22 sm:h-26 rounded-2xl border border-dashed border-slate-800/60 bg-slate-900/20 shadow-inner"
            />
          );
        }

        const isSelected = selectedPieceId === piece.id;
        const canFit = canFitMap[piece.id] ?? true;

        return (
          <div
            key={piece.id}
            id={`tray-piece-wrapper-${piece.id}`}
            className={`flex-1 flex items-center justify-center p-2.5 rounded-2xl transition-all cursor-grab active:cursor-grabbing select-none relative group h-22 sm:h-26 ${
              isSelected
                ? 'bg-slate-900/90 ring-2 ring-amber-400 shadow-[0_0_24px_rgba(245,158,11,0.25)] scale-105'
                : 'bg-slate-900/40 hover:bg-slate-850/60 hover:scale-102 border border-slate-800/70 shadow-sm'
            }`}
            onClick={() => onSelectPiece(isSelected ? null : piece)}
            onMouseDown={(e) => {
              if (e.button === 0) {
                onDragStart(piece, e.clientX, e.clientY);
              }
            }}
            onTouchStart={(e) => {
              if (e.touches.length > 0) {
                const touch = e.touches[0];
                onDragStart(piece, touch.clientX, touch.clientY);
              }
            }}
            role="button"
            tabIndex={0}
            aria-label={`${piece.name}, ${canFit ? 'placeable' : 'cannot fit currently'}`}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelectPiece(isSelected ? null : piece);
              }
            }}
          >
            <PieceBlock piece={piece} size="sm" canFit={canFit} />

            {/* Click to select hint badge */}
            {isSelected && (
              <span className="absolute -top-2.5 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/30 uppercase tracking-wider">
                Active
              </span>
            )}

            {!canFit && (
              <span className="absolute -bottom-2 text-[9px] font-bold text-rose-300 bg-rose-950/90 px-2 py-0.5 rounded-full border border-rose-800/70 shadow-sm">
                No space
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
};
