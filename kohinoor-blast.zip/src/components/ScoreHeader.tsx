import React, { useState } from 'react';
import { Trophy, Volume2, VolumeX, RotateCcw, HelpCircle, Gem, Layers, Zap } from 'lucide-react';
import { GameModeId } from '../types';

interface ScoreHeaderProps {
  score: number;
  highScore: number;
  combo: number;
  blastStreak: number;
  remainingTimerSec: number;
  currentMode: GameModeId;
  onSelectMode: (mode: GameModeId) => void;
  onReset: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onRegenerateClusters?: () => void;
}

export const ScoreHeader: React.FC<ScoreHeaderProps> = ({
  score,
  highScore,
  blastStreak,
  remainingTimerSec,
  currentMode,
  onSelectMode,
  onReset,
  isMuted,
  onToggleMute,
  onRegenerateClusters,
}) => {
  const [showHelp, setShowHelp] = useState(false);

  const isTimerActive = remainingTimerSec > 0;

  return (
    <header className="w-full max-w-xl mx-auto flex flex-col gap-3">
      {/* Top action bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-400 via-cyan-300 to-blue-600 p-[2px] shadow-lg shadow-sky-500/30 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center relative overflow-hidden group">
              {/* Subtle light-blue diamond shimmer reflection */}
              <div className="absolute inset-0 bg-gradient-to-br from-sky-300/20 via-transparent to-blue-600/10 pointer-events-none" />
              <Gem className="w-5 h-5 text-sky-300 fill-sky-400/40 drop-shadow-[0_0_10px_rgba(56,189,248,0.9)]" />
            </div>
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-1.5 drop-shadow">
              <span className="bg-gradient-to-r from-sky-200 via-cyan-300 to-sky-400 bg-clip-text text-transparent">
                KOHINOOR
              </span>{' '}
              <span>BLAST</span>
            </h1>
            <span className="text-[11px] text-sky-400/80 font-semibold tracking-wider uppercase">Diamond Edition</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            id="help-toggle-btn"
            onClick={() => setShowHelp(!showHelp)}
            className="p-2.5 rounded-2xl bg-slate-900/70 hover:bg-slate-800/80 text-slate-300 hover:text-white border border-slate-800/90 shadow-sm backdrop-blur transition-all active:scale-95"
            title="How to Play"
            aria-label="How to play instructions"
          >
            <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
          <button
            type="button"
            id="sound-toggle-btn"
            onClick={onToggleMute}
            className="p-2.5 rounded-2xl bg-slate-900/70 hover:bg-slate-800/80 text-slate-300 hover:text-white border border-slate-800/90 shadow-sm backdrop-blur transition-all active:scale-95"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            aria-label={isMuted ? 'Unmute sound effects' : 'Mute sound effects'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-rose-400" /> : <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" />}
          </button>
          <button
            type="button"
            id="reset-game-btn"
            onClick={onReset}
            className="p-2.5 rounded-2xl bg-slate-900/70 hover:bg-slate-800/80 text-slate-300 hover:text-white border border-slate-800/90 shadow-sm backdrop-blur transition-all active:scale-95"
            title="Restart Game"
            aria-label="Restart current game"
          >
            <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>

      {/* Score Dashboard */}
      <div className={`grid ${isTimerActive ? 'grid-cols-3' : 'grid-cols-2'} gap-2 sm:gap-3 text-center transition-all`}>
        {/* Current Score */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center shadow-[inset_0_1px_1px_rgba(255,255,255,0.06)] backdrop-blur-md">
          <span className="text-[10px] sm:text-xs uppercase tracking-wider text-slate-400 font-semibold mb-0.5">
            Score
          </span>
          <span className="text-2xl sm:text-3xl font-black text-amber-400 tracking-tight drop-shadow-sm font-mono">
            {score}
          </span>
        </div>

        {/* High Score */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center shadow-[inset_0_1px_1px_rgba(255,255,255,0.06)] backdrop-blur-md">
          <span className="text-[10px] sm:text-xs uppercase tracking-wider text-slate-400 font-semibold mb-0.5 flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" /> Best
          </span>
          <span className="text-2xl sm:text-3xl font-black text-yellow-400 tracking-tight drop-shadow-sm font-mono">
            {highScore}
          </span>
        </div>

        {/* Multiply Sign: ONLY shown when doubling (multiplying by 2) is active */}
        {isTimerActive && (
          <div className="bg-gradient-to-br from-amber-500/25 via-rose-500/25 to-amber-500/15 border-2 border-amber-400/80 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.3),inset_0_1px_2px_rgba(255,255,255,0.2)] backdrop-blur-md animate-pulse">
            <span className="text-[10px] sm:text-xs uppercase tracking-wider text-amber-300 font-extrabold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" /> Boost
            </span>
            <span className="text-2xl sm:text-3xl font-black text-amber-300 tracking-tight drop-shadow-[0_0_14px_rgba(245,158,11,0.8)] font-mono">
              ×2
            </span>
          </div>
        )}
      </div>

      {/* Mode Selector */}
      <div className="flex items-center justify-between gap-1 p-1 bg-slate-950/90 border border-slate-800/90 rounded-2xl shadow-inner">
        <button
          type="button"
          id="mode-classic-btn"
          onClick={() => onSelectMode('classic8')}
          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition-all ${
            currentMode === 'classic8'
              ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
          }`}
        >
          Classic 8×8
        </button>

        <button
          type="button"
          id="mode-clustered-btn"
          onClick={() => onSelectMode('clustered_areas')}
          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            currentMode === 'clustered_areas'
              ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Clustered
        </button>

        <button
          type="button"
          id="mode-mega-btn"
          onClick={() => onSelectMode('mega116')}
          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition-all ${
            currentMode === 'mega116'
              ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-md shadow-purple-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
          }`}
        >
          116 Squares
        </button>
      </div>

      {/* Optional button to regenerate clusters if in Clustered Areas mode */}
      {currentMode === 'clustered_areas' && onRegenerateClusters && (
        <div className="flex items-center justify-between px-1 text-xs text-slate-400">
          <span>Blocks grouped together in starting areas</span>
          <button
            type="button"
            id="regen-clusters-btn"
            onClick={onRegenerateClusters}
            className="text-cyan-400 hover:text-cyan-300 font-medium underline underline-offset-2 flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" /> New Cluster Layout
          </button>
        </div>
      )}

      {/* How to Play Accordion */}
      {showHelp && (
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 space-y-2.5 animate-in fade-in">
          <div className="font-bold text-white flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-amber-400 font-extrabold">
              <Zap className="w-4 h-4" /> Scoring Rules & How to Play
            </span>
            <button
              type="button"
              onClick={() => setShowHelp(false)}
              className="text-slate-500 hover:text-white font-mono text-sm"
            >
              ✕
            </button>
          </div>
          <div className="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/80 space-y-1">
            <div className="font-semibold text-white">⚡ Scoring System:</div>
            <div className="text-slate-300">
              • <strong>First Blast:</strong> Awards <strong>20 points</strong>.
            </div>
            <div className="text-slate-300">
              • <strong>Double Score (×2):</strong> Trigger another blast quickly to activate the <strong>×2</strong> multiplier!
            </div>
          </div>
          <ul className="list-disc pl-4 space-y-1 text-slate-300">
            <li><strong>Drag & Drop</strong> or <strong>Tap to Select</strong> pieces from the tray onto the grid.</li>
            <li>Fill an entire row or column to trigger a <strong>BLAST</strong>.</li>
            <li><strong>Clustered Areas Mode:</strong> Features small squares clustered together in key areas.</li>
          </ul>
        </div>
      )}
    </header>
  );
};
