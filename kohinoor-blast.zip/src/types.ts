export type CellColor = 
  | 'ruby'
  | 'emerald'
  | 'sapphire'
  | 'amber'
  | 'amethyst'
  | 'cyan'
  | 'coral'
  | 'tangerine'
  | 'slate';

export interface GridCell {
  filled: boolean;
  color?: CellColor;
  isBlasting?: boolean;
  isPreview?: boolean;
  isValidPreview?: boolean;
}

export interface PieceShape {
  id: string;
  name: string;
  matrix: number[][]; // 1 for filled cell, 0 for empty
  color: CellColor;
  width: number;
  height: number;
}

export interface PlacedPosition {
  row: number;
  col: number;
}

export type GameModeId = 'classic8' | 'clustered_areas' | 'mega116';

export interface GameModeConfig {
  id: GameModeId;
  name: string;
  description: string;
  rows: number;
  cols: number;
  initialClustersName?: string;
}

export interface ComboNotification {
  id: number;
  text: string;
  subtext?: string;
  count: number;
  multiplier: number;
}
