class SoundEffects {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  constructor() {
    // AudioContext is initialized on first user interaction
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  /**
   * Snappy, tactile bubble/wood pop when picking up or touching a piece
   */
  playPick() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;

      // Primary bubbly pitch blip
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(860, now + 0.045);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.055);

      // Light click transient for physical feel
      const click = this.ctx.createOscillator();
      const clickGain = this.ctx.createGain();
      click.type = 'triangle';
      click.frequency.setValueAtTime(1400, now);
      click.frequency.exponentialRampToValueAtTime(300, now + 0.02);

      clickGain.gain.setValueAtTime(0.08, now);
      clickGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      click.connect(clickGain);
      clickGain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.06);
      click.start(now);
      click.stop(now + 0.03);
    } catch {
      // Audio playback failsafe
    }
  }

  /**
   * Satisfying physical wooden block snap / thud when placing a piece
   */
  playDrop() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;

      // 1. Resonant wooden block body (sine/triangle sweep)
      const body = this.ctx.createOscillator();
      const bodyGain = this.ctx.createGain();
      body.type = 'sine';
      body.frequency.setValueAtTime(260, now);
      body.frequency.exponentialRampToValueAtTime(80, now + 0.075);

      bodyGain.gain.setValueAtTime(0.24, now);
      bodyGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.085);

      body.connect(bodyGain);
      bodyGain.connect(this.ctx.destination);

      // 2. Crisp wooden contact click
      const click = this.ctx.createOscillator();
      const clickGain = this.ctx.createGain();
      click.type = 'triangle';
      click.frequency.setValueAtTime(1600, now);
      click.frequency.exponentialRampToValueAtTime(220, now + 0.025);

      clickGain.gain.setValueAtTime(0.12, now);
      clickGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.03);

      click.connect(clickGain);
      clickGain.connect(this.ctx.destination);

      // 3. Sub-bass acoustic impact
      const sub = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(100, now);
      sub.frequency.exponentialRampToValueAtTime(45, now + 0.09);

      subGain.gain.setValueAtTime(0.15, now);
      subGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.095);

      sub.connect(subGain);
      subGain.connect(this.ctx.destination);

      body.start(now);
      body.stop(now + 0.09);
      click.start(now);
      click.stop(now + 0.035);
      sub.start(now);
      sub.stop(now + 0.1);
    } catch {
      // Audio failsafe
    }
  }

  /**
   * Crystal bell cascade & arcade blast sound with sub impact and shimmering harmonics
   */
  playClear(linesCount: number = 1, combo: number = 1) {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;

      // 1. Deep blast explosion impact
      const subImpact = this.ctx.createOscillator();
      const subImpactGain = this.ctx.createGain();
      subImpact.type = 'sine';
      subImpact.frequency.setValueAtTime(150, now);
      subImpact.frequency.exponentialRampToValueAtTime(42, now + 0.18);

      subImpactGain.gain.setValueAtTime(0.3, now);
      subImpactGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);

      subImpact.connect(subImpactGain);
      subImpactGain.connect(this.ctx.destination);
      subImpact.start(now);
      subImpact.stop(now + 0.22);

      // 2. Pentatonic crystal bell scale frequencies based on combo
      const pentatonic = [
        523.25, // C5
        587.33, // D5
        659.25, // E5
        783.99, // G5
        880.0,  // A5
        1046.5, // C6
        1174.66,// D6
        1318.51,// E6
        1567.98,// G6
        1760.0, // A6
        2093.0, // C7
      ];

      const startIndex = Math.min((combo - 1) * 2, pentatonic.length - 4);
      const noteCount = Math.min(3 + linesCount, 5);

      for (let i = 0; i < noteCount; i++) {
        const freq = pentatonic[Math.min(startIndex + i, pentatonic.length - 1)];
        const startTime = now + i * 0.055;
        const duration = 0.38 + i * 0.04;

        // Fundamental bell tone
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.18, startTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + duration + 0.01);

        // Harmonic shimmer overtone (2.76x bell harmonic)
        const shimmer = this.ctx.createOscillator();
        const shimmerGain = this.ctx.createGain();
        shimmer.type = 'triangle';
        shimmer.frequency.setValueAtTime(freq * 2.0, startTime);

        shimmerGain.gain.setValueAtTime(0.06, startTime);
        shimmerGain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration * 0.7);

        shimmer.connect(shimmerGain);
        shimmerGain.connect(this.ctx.destination);
        shimmer.start(startTime);
        shimmer.stop(startTime + duration + 0.01);
      }
    } catch {
      // Audio failsafe
    }
  }

  /**
   * Gentle, warm descending music-box/marimba chord progression for game over
   */
  playGameOver() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // Gentle melancholic descending chime: F5 -> Eb5 -> Db5 -> Bb4
      const notes = [698.46, 622.25, 554.37, 466.16];

      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const startTime = now + idx * 0.14;
        const duration = 0.45;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.16, startTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + duration + 0.02);
      });
    } catch {
      // Audio failsafe
    }
  }
}

export const soundFx = new SoundEffects();
