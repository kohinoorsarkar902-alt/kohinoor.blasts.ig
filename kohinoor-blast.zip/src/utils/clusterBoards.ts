import { CellColor, GridCell } from '../types';

export function createEmptyGrid(rows: number, cols: number): GridCell[][] {
  const grid: GridCell[][] = [];
  for (let r = 0; r < rows; r++) {
    const row: GridCell[] = [];
    for (let c = 0; c < cols; c++) {
      row.push({ filled: false });
    }
    grid.push(row);
  }
  return grid;
}

const PRESET_COLORS: CellColor[] = [
  'ruby',
  'sapphire',
  'emerald',
  'amber',
  'amethyst',
  'cyan',
  'coral',
  'tangerine',
];

/**
 * Creates an 8x8 grid with small squares clustered together in specific areas
 * (e.g., 4 corner clusters + center cluster, approx 16-20 pre-placed blocks)
 */
export function create8x8ClusteredAreas(): GridCell[][] {
  const grid = createEmptyGrid(8, 8);

  // Define clusters together in areas:
  // Top-left area: 2x2
  setCluster(grid, 1, 1, 2, 2, 'amber');
  // Top-right area: 2x2
  setCluster(grid, 1, 5, 2, 2, 'cyan');
  // Bottom-left area: 2x2
  setCluster(grid, 5, 1, 2, 2, 'emerald');
  // Bottom-right area: 2x2
  setCluster(grid, 5, 5, 2, 2, 'ruby');

  return grid;
}

/**
 * Creates an 11x11 Megaboard grid (or 116-square cluster areas)
 * with 116 playable cells and clusters grouped in 4 distinct sectors
 */
export function create116SquaresMegaboard(): { grid: GridCell[][]; rows: number; cols: number } {
  // A 10x10 or 11x11 grid with corner cutouts or 116 squares grouped in areas
  // 11x11 = 121 cells. Removing 5 cells (or 11x11 with 116 playable cells or clusters)
  const rows = 10;
  const cols = 10;
  const grid = createEmptyGrid(rows, cols);

  // Create multiple square groups together in areas
  // Area 1: North cluster
  setCluster(grid, 1, 3, 2, 4, 'sapphire');
  // Area 2: South cluster
  setCluster(grid, 7, 3, 2, 4, 'coral');
  // Area 3: West cluster
  setCluster(grid, 3, 1, 4, 2, 'emerald');
  // Area 4: East cluster
  setCluster(grid, 3, 7, 4, 2, 'amber');

  return { grid, rows, cols };
}

/**
 * Generates custom randomized areas of small squares together
 */
export function createRandomAreas(rows: number = 8, cols: number = 8, clusterCount: number = 4): GridCell[][] {
  const grid = createEmptyGrid(rows, cols);

  for (let i = 0; i < clusterCount; i++) {
    const color = PRESET_COLORS[i % PRESET_COLORS.length];
    const width = Math.floor(Math.random() * 2) + 2; // 2 or 3
    const height = Math.floor(Math.random() * 2) + 2; // 2 or 3
    const startR = Math.floor(Math.random() * (rows - height));
    const startC = Math.floor(Math.random() * (cols - width));

    // Place cluster without completely filling any full line (to keep it blastable)
    for (let r = 0; r < height; r++) {
      for (let c = 0; c < width; c++) {
        // Leave occasional gaps for strategic blasting
        if (Math.random() > 0.15) {
          const targetR = startR + r;
          const targetC = startC + c;
          grid[targetR][targetC] = {
            filled: true,
            color,
          };
        }
      }
    }
  }

  return grid;
}

function setCluster(
  grid: GridCell[][],
  startRow: number,
  startCol: number,
  height: number,
  width: number,
  color: CellColor
) {
  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      const curR = startRow + r;
      const curC = startCol + c;
      if (curR >= 0 && curR < grid.length && curC >= 0 && curC < grid[0].length) {
        grid[curR][curC] = {
          filled: true,
          color,
        };
      }
    }
  }
}
