import { CellColor, GridCell, PieceShape } from '../types';

export const COLOR_STYLES: Record<CellColor, {
  bg: string;
  gradient: string;
  borderTop: string;
  borderBottom: string;
  glow: string;
  accent: string;
  hologram: string;
}> = {
  ruby: {
    bg: 'bg-rose-500',
    gradient: 'bg-gradient-to-br from-rose-400 via-rose-500 to-rose-700',
    borderTop: 'border-t-rose-200/80 border-l-rose-200/60',
    borderBottom: 'border-b-rose-950/70 border-r-rose-950/70',
    glow: 'shadow-[0_4px_16px_rgba(244,63,94,0.45)]',
    accent: '#f43f5e',
    hologram: 'bg-rose-500/30 border-rose-400/80 shadow-[0_0_12px_rgba(244,63,94,0.5)]',
  },
  emerald: {
    bg: 'bg-emerald-500',
    gradient: 'bg-gradient-to-br from-emerald-300 via-emerald-500 to-emerald-700',
    borderTop: 'border-t-emerald-200/80 border-l-emerald-200/60',
    borderBottom: 'border-b-emerald-950/70 border-r-emerald-950/70',
    glow: 'shadow-[0_4px_16px_rgba(16,185,129,0.45)]',
    accent: '#10b981',
    hologram: 'bg-emerald-500/30 border-emerald-400/80 shadow-[0_0_12px_rgba(16,185,129,0.5)]',
  },
  sapphire: {
    bg: 'bg-blue-500',
    gradient: 'bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-700',
    borderTop: 'border-t-sky-200/80 border-l-sky-200/60',
    borderBottom: 'border-b-indigo-950/70 border-r-indigo-950/70',
    glow: 'shadow-[0_4px_16px_rgba(59,130,246,0.45)]',
    accent: '#3b82f6',
    hologram: 'bg-blue-500/30 border-blue-400/80 shadow-[0_0_12px_rgba(59,130,246,0.5)]',
  },
  amber: {
    bg: 'bg-amber-400',
    gradient: 'bg-gradient-to-br from-yellow-300 via-amber-400 to-amber-600',
    borderTop: 'border-t-yellow-100/90 border-l-yellow-100/70',
    borderBottom: 'border-b-amber-950/70 border-r-amber-950/70',
    glow: 'shadow-[0_4px_16px_rgba(245,158,11,0.45)]',
    accent: '#f59e0b',
    hologram: 'bg-amber-400/30 border-amber-300/80 shadow-[0_0_12px_rgba(245,158,11,0.5)]',
  },
  amethyst: {
    bg: 'bg-purple-500',
    gradient: 'bg-gradient-to-br from-fuchsia-400 via-purple-500 to-purple-800',
    borderTop: 'border-t-purple-200/80 border-l-purple-200/60',
    borderBottom: 'border-b-purple-950/70 border-r-purple-950/70',
    glow: 'shadow-[0_4px_16px_rgba(168,85,247,0.45)]',
    accent: '#a855f7',
    hologram: 'bg-purple-500/30 border-purple-400/80 shadow-[0_0_12px_rgba(168,85,247,0.5)]',
  },
  cyan: {
    bg: 'bg-cyan-400',
    gradient: 'bg-gradient-to-br from-cyan-200 via-cyan-400 to-teal-600',
    borderTop: 'border-t-cyan-100/90 border-l-cyan-100/70',
    borderBottom: 'border-b-teal-950/70 border-r-teal-950/70',
    glow: 'shadow-[0_4px_16px_rgba(6,182,212,0.45)]',
    accent: '#06b6d4',
    hologram: 'bg-cyan-400/30 border-cyan-300/80 shadow-[0_0_12px_rgba(6,182,212,0.5)]',
  },
  coral: {
    bg: 'bg-pink-500',
    gradient: 'bg-gradient-to-br from-pink-300 via-pink-500 to-rose-700',
    borderTop: 'border-t-pink-200/80 border-l-pink-200/60',
    borderBottom: 'border-b-pink-950/70 border-r-pink-950/70',
    glow: 'shadow-[0_4px_16px_rgba(236,72,153,0.45)]',
    accent: '#ec4899',
    hologram: 'bg-pink-500/30 border-pink-400/80 shadow-[0_0_12px_rgba(236,72,153,0.5)]',
  },
  tangerine: {
    bg: 'bg-orange-500',
    gradient: 'bg-gradient-to-br from-orange-300 via-orange-500 to-orange-700',
    borderTop: 'border-t-orange-200/80 border-l-orange-200/60',
    borderBottom: 'border-b-orange-950/70 border-r-orange-950/70',
    glow: 'shadow-[0_4px_16px_rgba(249,115,22,0.45)]',
    accent: '#f97316',
    hologram: 'bg-orange-500/30 border-orange-400/80 shadow-[0_0_12px_rgba(249,115,22,0.5)]',
  },
  slate: {
    bg: 'bg-slate-600',
    gradient: 'bg-gradient-to-br from-slate-400 via-slate-600 to-slate-800',
    borderTop: 'border-t-slate-300/70 border-l-slate-300/50',
    borderBottom: 'border-b-slate-950/80 border-r-slate-950/80',
    glow: 'shadow-[0_2px_10px_rgba(100,116,139,0.35)]',
    accent: '#64748b',
    hologram: 'bg-slate-600/30 border-slate-400/60 shadow-[0_0_8px_rgba(100,116,139,0.3)]',
  },
};

export const RAW_SHAPES: Array<{
  name: string;
  matrix: number[][];
  color: CellColor;
  weight?: number;
}> = [
  // 1x1 Dot
  {
    name: 'Dot',
    matrix: [[1]],
    color: 'amber',
    weight: 2,
  },
  // Bars
  {
    name: 'Bar 2H',
    matrix: [[1, 1]],
    color: 'cyan',
    weight: 3,
  },
  {
    name: 'Bar 2V',
    matrix: [[1], [1]],
    color: 'cyan',
    weight: 3,
  },
  {
    name: 'Bar 3H',
    matrix: [[1, 1, 1]],
    color: 'emerald',
    weight: 3,
  },
  {
    name: 'Bar 3V',
    matrix: [[1], [1], [1]],
    color: 'emerald',
    weight: 3,
  },
  {
    name: 'Bar 4H',
    matrix: [[1, 1, 1, 1]],
    color: 'sapphire',
    weight: 2,
  },
  {
    name: 'Bar 4V',
    matrix: [[1], [1], [1], [1]],
    color: 'sapphire',
    weight: 2,
  },
  {
    name: 'Bar 5H',
    matrix: [[1, 1, 1, 1, 1]],
    color: 'amethyst',
    weight: 1,
  },
  {
    name: 'Bar 5V',
    matrix: [[1], [1], [1], [1], [1]],
    color: 'amethyst',
    weight: 1,
  },
  // Squares
  {
    name: 'Square 2x2',
    matrix: [
      [1, 1],
      [1, 1],
    ],
    color: 'ruby',
    weight: 3,
  },
  {
    name: 'Square 3x3',
    matrix: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    color: 'coral',
    weight: 1,
  },
  // Corner 2x2 (3 blocks)
  {
    name: 'Corner TL',
    matrix: [
      [1, 1],
      [1, 0],
    ],
    color: 'tangerine',
    weight: 3,
  },
  {
    name: 'Corner TR',
    matrix: [
      [1, 1],
      [0, 1],
    ],
    color: 'tangerine',
    weight: 3,
  },
  {
    name: 'Corner BL',
    matrix: [
      [1, 0],
      [1, 1],
    ],
    color: 'tangerine',
    weight: 3,
  },
  {
    name: 'Corner BR',
    matrix: [
      [0, 1],
      [1, 1],
    ],
    color: 'tangerine',
    weight: 3,
  },
  // L-Shapes 3x2 (4 blocks)
  {
    name: 'L-Shape Normal',
    matrix: [
      [1, 0],
      [1, 0],
      [1, 1],
    ],
    color: 'amber',
    weight: 2,
  },
  {
    name: 'L-Shape Inverted',
    matrix: [
      [0, 1],
      [0, 1],
      [1, 1],
    ],
    color: 'amber',
    weight: 2,
  },
  {
    name: 'L-Shape Flat Left',
    matrix: [
      [1, 1, 1],
      [1, 0, 0],
    ],
    color: 'amber',
    weight: 2,
  },
  {
    name: 'L-Shape Flat Right',
    matrix: [
      [1, 1, 1],
      [0, 0, 1],
    ],
    color: 'amber',
    weight: 2,
  },
  // T-Shapes (4 blocks)
  {
    name: 'T-Shape Down',
    matrix: [
      [1, 1, 1],
      [0, 1, 0],
    ],
    color: 'amethyst',
    weight: 2,
  },
  {
    name: 'T-Shape Up',
    matrix: [
      [0, 1, 0],
      [1, 1, 1],
    ],
    color: 'amethyst',
    weight: 2,
  },
  {
    name: 'T-Shape Right',
    matrix: [
      [1, 0],
      [1, 1],
      [1, 0],
    ],
    color: 'amethyst',
    weight: 2,
  },
  // Z and S shapes
  {
    name: 'Z-Shape',
    matrix: [
      [1, 1, 0],
      [0, 1, 1],
    ],
    color: 'coral',
    weight: 2,
  },
  {
    name: 'S-Shape',
    matrix: [
      [0, 1, 1],
      [1, 1, 0],
    ],
    color: 'emerald',
    weight: 2,
  },
];

let pieceCounter = 1;

export function getRandomPiece(): PieceShape {
  // Weighted selection
  const totalWeight = RAW_SHAPES.reduce((sum, item) => sum + (item.weight || 1), 0);
  let random = Math.random() * totalWeight;

  let selected = RAW_SHAPES[0];
  for (const item of RAW_SHAPES) {
    const weight = item.weight || 1;
    if (random < weight) {
      selected = item;
      break;
    }
    random -= weight;
  }

  const height = selected.matrix.length;
  const width = selected.matrix[0].length;

  return {
    id: `piece-${Date.now()}-${pieceCounter++}-${Math.random().toString(36).substring(2, 6)}`,
    name: selected.name,
    matrix: selected.matrix.map((row) => [...row]),
    color: selected.color,
    width,
    height,
  };
}

export function generateTray(count: number = 3): PieceShape[] {
  const pieces: PieceShape[] = [];
  for (let i = 0; i < count; i++) {
    pieces.push(getRandomPiece());
  }
  return pieces;
}

/**
 * Checks if a piece can be placed at a specific board coordinate
 */
export function canPlacePieceAt(
  grid: GridCell[][],
  piece: PieceShape,
  targetRow: number,
  targetCol: number
): boolean {
  const rows = grid.length;
  const cols = grid[0].length;

  for (let r = 0; r < piece.height; r++) {
    for (let c = 0; c < piece.width; c++) {
      if (piece.matrix[r][c] === 1) {
        const boardR = targetRow + r;
        const boardC = targetCol + c;

        // Check board bounds
        if (boardR < 0 || boardR >= rows || boardC < 0 || boardC >= cols) {
          return false;
        }

        // Check if cell is occupied
        if (grid[boardR][boardC].filled) {
          return false;
        }
      }
    }
  }

  return true;
}

/**
 * Checks if a piece can fit anywhere on the entire grid
 */
export function canPieceFitAnywhere(grid: GridCell[][], piece: PieceShape): boolean {
  const rows = grid.length;
  const cols = grid[0].length;

  for (let r = 0; r <= rows - piece.height; r++) {
    for (let c = 0; c <= cols - piece.width; c++) {
      if (canPlacePieceAt(grid, piece, r, c)) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Checks if ANY piece remaining in tray can fit on the board
 */
export function isGameOver(grid: GridCell[][], tray: PieceShape[]): boolean {
  if (tray.length === 0) return false;
  return !tray.some((piece) => canPieceFitAnywhere(grid, piece));
}
